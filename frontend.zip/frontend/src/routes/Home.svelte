<script>
    import { push } from 'svelte-spa-router';
    import Navbar from '../components/Navbar.svelte';
</script>

<Navbar />

<style>
  h1{
    text-align: center;
  }
  .container{
    text-align: center;
  }
</style>


<div class="container">
  <h1>채용 공고 메인 페이지입니다.</h1>
</div>
