<script>
    import { Router, push } from 'svelte-spa-router';
    import Main from './routes/Main.svelte';
    // import Home from './routes/Home.svelte';
    // import Login from './routes/Login.svelte';
    // import Signup from './routes/Signup.svelte';
    // import JobPostList from './routes/jobpost/JobPostList.svelte';
    // import JobPost from './routes/jobpost/JobPost.svelte';
    // import JobDetail from './routes/jobpost/JobDetail.svelte';
    // import UserProfile from './routes/UserProfile.svelte';
  
    // import { isLoggedIn, userType } from './lib/store';
  
    // let loggedIn = false;
    // let currentUserType = '1';
  
    // // 로그인 상태 구독
    // isLoggedIn.subscribe(value => {
    //   loggedIn = value;
    // });
  
    // // 사용자 유형 상태 구독
    // userType.subscribe(value => {
    //   currentUserType = value;
    // });

    // if (!localStorage.getItem('token')) {
    //     push('/login', { replace: true });
    // }

    // 경로 설정
    const routes = {
      '/': Main,
    //   '/login': Login,
    //   '/signup': Signup,
    //   '/home': Home
    //   '/jobpostlist': JobPostList,
    //   '/jobpost': JobPost,
    //   '/jobdetail/:id': JobDetail,
    //   '/profile': UserProfile
    };
  </script>
  
  <Router {routes} />
  