import App from './App.svelte'
// import './styles/styles.css';
import './app.css'

// import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
// import '../node_modules/bootstrap/dist/js/bootstrap.min.js'

const app = new App({
  target: document.getElementById('app'),
})

export default app